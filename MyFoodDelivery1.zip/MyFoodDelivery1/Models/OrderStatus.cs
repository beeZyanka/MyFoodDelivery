﻿namespace MyFoodDelivery1.Models
{
    public enum OrderStatus
    {
        New = 0,        // нове
        InProgress = 1, // готується
        Completed = 2,  // завершене
        Cancelled = 3 //скасоване
    }

}
